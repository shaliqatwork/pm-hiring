(function () {
  "use strict";

  var PLACEHOLDER = "PASTE_PUBLISHED_GOOGLE_FORM_URL_HERE";

  // Returns an embeddable URL, or an error message explaining why the
  // configured value can't be embedded.
  function resolveFormUrl(raw) {
    var value = (raw || "").trim();
    if (!value || value === PLACEHOLDER) {
      return { error: "The application form hasn't been connected yet." };
    }

    var url;
    try {
      url = new URL(value);
    } catch (e) {
      return { error: "The configured form address isn't a valid URL." };
    }

    if (url.hostname !== "docs.google.com" || url.pathname.indexOf("/forms/") !== 0) {
      return { error: "The configured address isn't a full Google Forms link (docs.google.com/forms/...)." };
    }
    if (/\/edit\/?$/.test(url.pathname)) {
      return { error: "The configured address is the form editor link. Use the published responder link ending in /viewform." };
    }

    var openUrl = url.toString();
    url.searchParams.set("embedded", "true");
    return { url: url.toString(), openUrl: openUrl };
  }

  function mountForm() {
    var frame = document.getElementById("application-form");
    var notice = document.getElementById("form-notice");
    var fallback = document.getElementById("form-open-link");
    if (!frame || !notice) return;

    var result = resolveFormUrl(window.GOOGLE_FORM_URL);

    if (result.error) {
      frame.hidden = true;
      notice.hidden = false;
      notice.querySelector("[data-notice-text]").textContent = result.error;
      if (fallback) fallback.hidden = true;
      return;
    }

    frame.src = result.url;
    frame.hidden = false;
    notice.hidden = true;
    if (fallback) {
      fallback.href = result.openUrl;
      fallback.hidden = false;
    }
  }

  // Move keyboard focus to the target of in-page links so screen reader
  // and keyboard users land where the page scrolled to.
  function enhanceInPageLinks() {
    document.querySelectorAll('a[href^="#"]').forEach(function (link) {
      link.addEventListener("click", function () {
        var id = link.getAttribute("href").slice(1);
        var target = id && document.getElementById(id);
        if (!target) return;
        if (!target.hasAttribute("tabindex")) target.setAttribute("tabindex", "-1");
        // Let the browser handle smooth scrolling via CSS, then move focus.
        window.setTimeout(function () {
          target.focus({ preventScroll: true });
        }, 0);
      });
    });
  }

  document.getElementById("year").textContent = new Date().getFullYear();
  mountForm();
  enhanceInPageLinks();
})();
